export class Workout{

    constructor(public title: string, public note: string, public calPerMin: number, public category: string, public enabled : boolean){
        
    }

}