import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-end-workout',
  templateUrl: './end-workout.component.html',
  styleUrls: ['./end-workout.component.css']
})
export class EndWorkoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
