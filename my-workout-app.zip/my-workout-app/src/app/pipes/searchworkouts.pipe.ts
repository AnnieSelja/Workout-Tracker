import { Workout } from './../models/Workout';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'searchWorkouts'
})
export class SearchWorkoutsPipe implements PipeTransform {

    transform(workouts: Array<Workout>, workoutName?: string) {
        console.log(workouts);
        console.log(workoutName);
        if(workoutName){
            let filteredWorkouts: Array<Workout> = null;
            filteredWorkouts = workouts.filter(workout => workout.title.startsWith(workoutName))
            return filteredWorkouts;
        }
        return workouts;
    }

}
