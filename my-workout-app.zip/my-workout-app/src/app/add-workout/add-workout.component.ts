import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-workout',
  templateUrl: './add-workout.component.html',
  styleUrls: ['./add-workout.component.css']
})
export class AddWorkoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
