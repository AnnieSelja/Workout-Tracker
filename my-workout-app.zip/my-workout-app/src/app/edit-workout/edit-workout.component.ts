import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-workout',
  templateUrl: './edit-workout.component.html',
  styleUrls: ['./edit-workout.component.css']
})
export class EditWorkoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
