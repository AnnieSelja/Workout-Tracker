import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-workout',
  templateUrl: './track-workout.component.html',
  styleUrls: ['./track-workout.component.css']
})
export class TrackWorkoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
