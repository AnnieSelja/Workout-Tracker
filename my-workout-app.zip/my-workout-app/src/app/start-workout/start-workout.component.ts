import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-start-workout',
  templateUrl: './start-workout.component.html',
  styleUrls: ['./start-workout.component.css']
})
export class StartWorkoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
